import React from "react";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
export default function LayerOrderPanel({ layers, selectedId, setSelectedId, moveLayer }) {
  // 드래그 끝났을 때 순서 변경
  const handleOnDragEnd = (result) => {
    if (!result.destination) return;
    const fromIndex = result.source.index;
    const toIndex = result.destination.index;
    if (fromIndex !== toIndex) {
      moveLayer(fromIndex, toIndex);
    }
  };

  return (
    <div style={{ marginBottom: 15 }}>
      <h4>📑 레이어 순서 (드래그로 변경)</h4>
      <DragDropContext onDragEnd={handleOnDragEnd}>
        <Droppable droppableId="layerList">
          {(provided) => (
            <ul
              {...provided.droppableProps}
              ref={provided.innerRef}
              style={{
                listStyle: "none",
                padding: 0,
                margin: 0,
              }}
            >
              {layers.map((layer, index) => (
                <Draggable key={layer.id} draggableId={layer.id.toString()} index={index}>
                  {(provided, snapshot) => (
                    <li
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        marginBottom: 4,
                        padding: "6px 8px",
                        background:
                          layer.id === selectedId
                            ? "#d0ebff"
                            : snapshot.isDragging
                            ? "#e6f7ff"
                            : "#f0f0f0",
                        border: "1px solid #ccc",
                        cursor: "grab",
                        ...provided.draggableProps.style,
                      }}
                      onClick={() => setSelectedId(layer.id)}
                    >
                      <span>{layer.name}</span>
                      <span style={{ fontSize: 12, opacity: 0.6 }}>{layer.type}</span>
                    </li>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </ul>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}
