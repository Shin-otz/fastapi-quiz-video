import React from "react";

export default function Timeline({
  layers,
  currentTime,
  setCurrentTime,
  selectedId,
  setSelectedId,
  maxTime,
  timelineWidth,
  rowHeight = 30,
}) {
  const handleMouseDownOnTime = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    let newTime = (x / timelineWidth) * maxTime;
    if (newTime < 0) newTime = 0;
    if (newTime > maxTime) newTime = maxTime;
    setCurrentTime(parseFloat(newTime.toFixed(1)));
  };

  return (
    <div
      style={{
        position: "relative",
        width: timelineWidth,
        height: layers.length * rowHeight + 30,
        border: "1px solid #aaa",
        background: "#ddd",
      }}
    >
      {/* 클릭 영역 */}
      <div
        style={{ position: "absolute", top: 0, left: 0, height: 20, width: "100%", background: "#ccc", cursor: "pointer" }}
        onMouseDown={handleMouseDownOnTime}
      >
        <div
          style={{
            position: "absolute",
            left: (currentTime / maxTime) * timelineWidth - 6,
            top: 12,
            width: 0,
            height: 0,
            borderLeft: "6px solid transparent",
            borderRight: "6px solid transparent",
            borderBottom: "8px solid red",
          }}
        />
      </div>

      {/* 현재시간 세로선 */}
      <div
        style={{
          position: "absolute",
          left: (currentTime / maxTime) * timelineWidth,
          top: 0,
          width: 2,
          height: layers.length * rowHeight + 30,
          background: "red",
        }}
      />

      {/* 레이어 막대 */}
      {layers.map((layer, idx) => {
        const start = layer.startTime || 0;
        const end = layer.endTime || 0;
        const left = (start / maxTime) * timelineWidth;
        const width = ((end - start) / maxTime) * timelineWidth;
        const top = 20 + idx * rowHeight;

        const isSelected = layer.id === selectedId;
        const color = layer.type === "audio" ? "green" : "blue";

        return (
          <div
            key={layer.id}
            onClick={() => setSelectedId(layer.id)}
            style={{
              position: "absolute",
              left,
              top: top + 5,
              width,
              height: 20,
              background: isSelected ? "rgba(255,0,0,0.6)" : color,
              border: isSelected ? "2px solid red" : "1px solid #333",
              display: "flex",
              alignItems: "center",
              paddingLeft: 4,
              color: "#fff",
              fontSize: 12,
              cursor: "pointer",
              whiteSpace: "nowrap",
              overflow: "hidden",
            }}
          >
            {layer.name}
          </div>
        );
      })}
    </div>
  );
}
