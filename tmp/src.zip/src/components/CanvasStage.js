// 📂 src/components/CanvasStage.js
import React from "react";
import { Stage, Layer, Rect, Text } from "react-konva";
import ImageLayer from "./ImageLayer";

export default function CanvasStage({
  layers,
  selectedId,
  setSelectedId,
  handleDragEnd,
  popupVisible,
  setPopupVisible,
  setPopupPos,
  canvasRatio,
  setCanvasRatio,
  displayScale,
  setDisplayScale,
  updateLayer
}) {
  const resolutions = {
    "16:9": { width: 1920, height: 1080 },
    "1280x720": { width: 1280, height: 720 },
    "4:3": { width: 1024, height: 768 },
    "1:1": { width: 1080, height: 1080 },
    "9:16": { width: 1080, height: 1920 }
  };

  const realRes = resolutions[canvasRatio];
  const canvasWidth = realRes.width * displayScale;
  const canvasHeight = realRes.height * displayScale;

  // 윤곽선 속성
  const getOutlineProps = (layer) => {
    let strokeColor = layer.id === selectedId ? "red" : "gray";
    let opacity = 1;
    if (layer.outlineMode === "transparent") opacity = 0;
    else if (layer.outlineMode === "semi") opacity = 0.3;
    return { stroke: strokeColor, opacity };
  };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
      {/* 상단 설정 바 */}
      <div
        style={{
          height: 60,
          borderBottom: "1px solid #ccc",
          display: "flex",
          alignItems: "center",
          padding: "0 10px",
          gap: 10
        }}
      >
        <h4 style={{ margin: 0 }}>🖥️ 해상도</h4>
        <select
          value={canvasRatio}
          onChange={(e) => {
            setCanvasRatio(e.target.value);
          }}
        >
          <option value="16:9">1920x1080</option>
          <option value="1280x720">1280x720</option>
          <option value="4:3">1024x768</option>
          <option value="1:1">1080x1080</option>
          <option value="9:16">1080x1920</option>
        </select>
        <label>배율(%)</label>
        <input
          type="number"
          style={{ width: 80 }}
          value={displayScale * 100}
          onChange={(e) => {
            let val = Number(e.target.value);
            if (val < 10) val = 10;
            if (val > 200) val = 200;
            setDisplayScale(val / 100);
          }}
        />
        <span>{canvasWidth}x{canvasHeight}</span>
      </div>

      {/* 실제 캔버스 */}
      <div
        style={{
          flex: 1,
          background: "#eee",
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
        onClick={() => setPopupVisible(false)}
      >
        <Stage width={canvasWidth} height={canvasHeight} style={{ background: "#fff" }}>
          <Layer>
            <Rect
              x={0}
              y={0}
              width={canvasWidth}
              height={canvasHeight}
              stroke="black"
              strokeWidth={2}
              listening={false}
            />
            {layers.map((layer) => {
              const outline = getOutlineProps(layer);

              // 텍스트 레이어
              if (layer.type === "text") {
                return (
                  <React.Fragment key={layer.id}>
                    <Rect
                      x={layer.x}
                      y={layer.y}
                      width={layer.width}
                      height={layer.height}
                      fill={layer.backgroundColor}
                      opacity={layer.backgroundOpacity}
                      listening={false}
                    />
                    <Rect
                      x={layer.x}
                      y={layer.y}
                      width={layer.width}
                      height={layer.height}
                      stroke={outline.stroke}
                      opacity={outline.opacity}
                      dash={[4, 4]}
                      listening={false}
                    />
                    <Text
                      text={layer.text}
                      x={layer.x}
                      y={layer.y}
                      width={layer.width}
                      height={layer.height}
                      fontSize={layer.fontSize}
                      fontFamily={layer.fontFamily}
                      fill={layer.color}
                      align={layer.align}
                      verticalAlign="middle"
                      draggable
                      onDragEnd={(e) =>
                        handleDragEnd(layer.id, e.target.x(), e.target.y())
                      }
                      onClick={() => setSelectedId(layer.id)}
                      onContextMenu={(e) => {
                        e.evt.preventDefault();
                        setSelectedId(layer.id);
                        setPopupPos({ x: e.evt.clientX, y: e.evt.clientY });
                        popupVisible ? setPopupVisible(false) : setPopupVisible(true);
                      }}
                    />
                  </React.Fragment>
                );
              }

              // 이미지 레이어
              if (layer.type === "image") {
                return (
                  <ImageLayer
                    key={layer.id}
                    layer={layer}
                    canvasWidth={canvasWidth}
                    canvasHeight={canvasHeight}
                    isSelected={layer.id === selectedId}
                    onSelect={(id, pos, isContext) => {
                      setSelectedId(id);
                      if (isContext) {
                        setPopupPos(pos);
                        setPopupVisible(true);
                      }
                    }}
                    onDragEnd={handleDragEnd}
                  />
                );
              }

              return null;
            })}
          </Layer>
        </Stage>
      </div>
    </div>
  );
}
