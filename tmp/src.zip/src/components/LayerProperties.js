// 📂 src/components/LayerProperties.js
import React, { useState, useEffect } from "react";

export default function LayerProperties({ selectedLayer, updateLayer, deleteLayer, layers }) {
  const [gapBeforeInput, setGapBeforeInput] = useState("0");
  const [gapAfterInput, setGapAfterInput] = useState("0");

  useEffect(() => {
    if (selectedLayer) {
      setGapBeforeInput(String(selectedLayer.gapBefore ?? 0));
      setGapAfterInput(String(selectedLayer.gapAfter ?? 0));
    }
  }, [selectedLayer]);

  if (!selectedLayer) return <p>왼쪽에서 레이어를 선택해보세요.</p>;

  return (
    <div style={{ marginTop: 10 }}>
      <h3>⚙️ 레이어 속성</h3>

      <label>레이어 이름</label>
      <input
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.name}
        onChange={(e) => updateLayer(selectedLayer.id, "name", e.target.value)}
      />

      <label>타입</label>
      <p>{selectedLayer.type}</p>

      <label>크기 모드</label>
      <select
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.positionMode || "부분"}
        onChange={(e) => updateLayer(selectedLayer.id, "positionMode", e.target.value)}
      >
        <option value="전체">전체</option>
        <option value="부분">부분</option>
      </select>

      <label>시간 모드</label>
      <select
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.timeMode}
        onChange={(e) => updateLayer(selectedLayer.id, "timeMode", e.target.value)}
      >
        <option value="전체">전체</option>
        <option value="부분">부분</option>
      </select>

      <label>시작 시간</label>
      <input type="number" style={{ width: "100%", marginBottom: 10 }} value={selectedLayer.startTime || 0} disabled />
      <label>끝 시간</label>
      <input type="number" style={{ width: "100%", marginBottom: 10 }} value={selectedLayer.endTime || 0} disabled />

      <label>길이(duration, 초)</label>
      <input
        type="number"
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.duration || 0}
        onChange={(e) => updateLayer(selectedLayer.id, "duration", Number(e.target.value))}
      />

      <label>앞 gap(초)</label>
      <input
        type="number"
        style={{ width: "100%", marginBottom: 10 }}
        value={gapBeforeInput}
        onChange={(e) => setGapBeforeInput(e.target.value)}
        onBlur={() => updateLayer(selectedLayer.id, "gapBefore", Number(gapBeforeInput))}
      />

      <label>뒤 gap(초)</label>
      <input
        type="number"
        style={{ width: "100%", marginBottom: 10 }}
        value={gapAfterInput}
        onChange={(e) => setGapAfterInput(e.target.value)}
        onBlur={() => updateLayer(selectedLayer.id, "gapAfter", Number(gapAfterInput))}
      />

      <label>Canvas 정렬</label>
      <select
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.canvasAlign || "custom"}
        onChange={(e) => updateLayer(selectedLayer.id, "canvasAlign", e.target.value)}
      >
        <option value="custom">사용자 지정</option>
        <option value="left">좌측</option>
        <option value="center">중앙</option>
        <option value="right">우측</option>
      </select>

      {/* ===== TEXT ===== */}
      {selectedLayer.type === "text" && (
        <>
          <h4>📝 텍스트 레이어</h4>
          <label>텍스트 내용</label>
          <input
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.text || ""}
            onChange={(e) => updateLayer(selectedLayer.id, "text", e.target.value)}
          />
          <label>MP3 URL</label>
          <input
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.mp3Url || ""}
            onChange={(e) => updateLayer(selectedLayer.id, "mp3Url", e.target.value)}
          />
          <label>글자 내부 정렬</label>
          <select
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.textAlign || "left"}
            onChange={(e) => updateLayer(selectedLayer.id, "textAlign", e.target.value)}
          >
            <option value="left">왼쪽</option>
            <option value="center">가운데</option>
            <option value="right">오른쪽</option>
          </select>
        </>
      )}

      {/* ===== IMAGE ===== */}
      {selectedLayer.type === "image" && (
        <>
          <h4>🖼 이미지 레이어</h4>
          <label>이미지 URL</label>
          <input
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.imgUrl || ""}
            onChange={(e) => updateLayer(selectedLayer.id, "imgUrl", e.target.value)}
          />

          <label>앞쪽 Pre-Gap(초)</label>
          <input
            type="number"
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.preGap || 0}
            onChange={(e) => updateLayer(selectedLayer.id, "preGap", Number(e.target.value))}
          />

          <label>뒤쪽 Post-Gap(초)</label>
          <input
            type="number"
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.postGap || 0}
            onChange={(e) => updateLayer(selectedLayer.id, "postGap", Number(e.target.value))}
          />

          {selectedLayer.timeMode === "부분" && (
            <>
              <label>시작 기준 레이어</label>
              <select
                style={{ width: "100%", marginBottom: 10 }}
                value={selectedLayer.linkedStartLayerId || ""}
                onChange={(e) =>
                  updateLayer(selectedLayer.id, "linkedStartLayerId", e.target.value ? Number(e.target.value) : null)
                }
              >
                <option value="">선택 안함</option>
                {layers
                  .filter(l => l.type === "text" || l.type === "countdown")
                  .map(l => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))}
              </select>

              <label>끝 기준 레이어</label>
              <select
                style={{ width: "100%", marginBottom: 10 }}
                value={selectedLayer.linkedEndLayerId || ""}
                onChange={(e) =>
                  updateLayer(selectedLayer.id, "linkedEndLayerId", e.target.value ? Number(e.target.value) : null)
                }
              >
                <option value="">선택 안함</option>
                {layers
                  .filter(l => l.type === "text" || l.type === "countdown")
                  .map(l => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))}
              </select>
            </>
          )}
        </>
      )}

      {/* ===== COUNTDOWN ===== */}
      {selectedLayer.type === "countdown" && (
        <>
          <h4>⏳ 카운트다운 레이어</h4>
          <label>카운트다운 시작 초</label>
          <input
            type="number"
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.countdownStart}
            onChange={(e) => updateLayer(selectedLayer.id, "countdownStart", Number(e.target.value))}
          />
          <label>글자 크기</label>
          <input
            type="number"
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.fontSize}
            onChange={(e) => updateLayer(selectedLayer.id, "fontSize", Number(e.target.value))}
          />
          <label>글자 색상</label>
          <input
            type="color"
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.color}
            onChange={(e) => updateLayer(selectedLayer.id, "color", e.target.value)}
          />
        </>
      )}

      {/* ===== AUDIO ===== */}
      {selectedLayer.type === "audio" && (
        <>
          <h4>🎧 오디오 레이어</h4>
          <label>오디오 URL</label>
          <input
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.audioUrl || ""}
            onChange={(e) => updateLayer(selectedLayer.id, "audioUrl", e.target.value)}
          />

          <label>앞쪽 Pre-Gap(초)</label>
          <input
            type="number"
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.preGap || 0}
            onChange={(e) => updateLayer(selectedLayer.id, "preGap", Number(e.target.value))}
          />

          <label>뒤쪽 Post-Gap(초)</label>
          <input
            type="number"
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.postGap || 0}
            onChange={(e) => updateLayer(selectedLayer.id, "postGap", Number(e.target.value))}
          />

          <label>시작 위치 모드</label>
          <select
            style={{ width: "100%", marginBottom: 10 }}
            value={selectedLayer.linkMode || "absolute"}
            onChange={(e) => updateLayer(selectedLayer.id, "linkMode", e.target.value)}
          >
            <option value="absolute">절대시간</option>
            <option value="relative">다른 레이어 기준</option>
          </select>

          {selectedLayer.linkMode === "relative" && (
            <>
              <label>기준 레이어</label>
              <select
                style={{ width: "100%", marginBottom: 10 }}
                value={selectedLayer.linkedLayerId || ""}
                onChange={(e) => updateLayer(selectedLayer.id, "linkedLayerId", Number(e.target.value))}
              >
                <option value="">선택</option>
                {layers.filter(l => l.type === "text").map(l => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>

              <label>기준점</label>
              <select
                style={{ width: "100%", marginBottom: 10 }}
                value={selectedLayer.relativeAnchor || "start"}
                onChange={(e) => updateLayer(selectedLayer.id, "relativeAnchor", e.target.value)}
              >
                <option value="start">시작 기준</option>
                <option value="end">끝 기준</option>
              </select>

              <label>Offset(초)</label>
              <input
                type="number"
                style={{ width: "100%", marginBottom: 10 }}
                value={selectedLayer.offset || 0}
                onChange={(e) => updateLayer(selectedLayer.id, "offset", Number(e.target.value))}
              />
            </>
          )}
        </>
      )}

      {/* 공통 크기/배경 */}
      <label>가로(px)</label>
      <input
        type="number"
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.width}
        onChange={(e) => updateLayer(selectedLayer.id, "width", Number(e.target.value))}
      />

      <label>세로(px)</label>
      <input
        type="number"
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.height}
        onChange={(e) => updateLayer(selectedLayer.id, "height", Number(e.target.value))}
      />

      <label>윤곽선 모드</label>
      <select
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.outlineMode}
        onChange={(e) => updateLayer(selectedLayer.id, "outlineMode", e.target.value)}
      >
        <option value="normal">노말</option>
        <option value="semi">반투명</option>
        <option value="transparent">투명</option>
      </select>

      <label>배경 색상</label>
      <input
        type="color"
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.backgroundColor}
        onChange={(e) => updateLayer(selectedLayer.id, "backgroundColor", e.target.value)}
      />

      <label>배경 투명도</label>
      <input
        type="range"
        min="0"
        max="1"
        step="0.1"
        style={{ width: "100%", marginBottom: 10 }}
        value={selectedLayer.backgroundOpacity}
        onChange={(e) => updateLayer(selectedLayer.id, "backgroundOpacity", Number(e.target.value))}
      />

      <hr style={{ margin: "20px 0" }} />
      <button
        style={{
          width: "100%",
          padding: "8px",
          background: "red",
          color: "#fff",
          border: "none",
          borderRadius: 4,
          cursor: "pointer",
        }}
        onClick={() => {
          if (window.confirm("정말 이 레이어를 삭제하시겠습니까?")) {
            deleteLayer(selectedLayer.id);
          }
        }}
      >
        🗑 레이어 삭제
      </button>
    </div>
  );
}
