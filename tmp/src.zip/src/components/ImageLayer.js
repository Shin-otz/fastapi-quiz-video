// 📂 src/components/ImageLayer.js
import React from "react";
import { Image as KonvaImage, Rect } from "react-konva";
import useImage from "use-image";

export default function ImageLayer({
  layer,
  canvasWidth,
  canvasHeight,
  isSelected,
  onSelect,
  onDragEnd
}) {
  const [image] = useImage(layer.imgUrl, 'anonymous'); // 이미지 로드

  const isFull = layer.positionMode === "전체";

  // 윤곽선 스타일
  const getOutline = () => {
    let strokeColor = isSelected ? "red" : "gray";
    let opacity = 1;
    if (layer.outlineMode === "transparent") opacity = 0;
    else if (layer.outlineMode === "semi") opacity = 0.3;
    return { stroke: strokeColor, opacity };
  };
  const outline = getOutline();

  return (
    <>
      {/* 이미지 본체 */}
      <KonvaImage
        image={image}
        x={isFull ? 0 : layer.x}
        y={isFull ? 0 : layer.y}
        width={isFull ? canvasWidth : layer.width}
        height={isFull ? canvasHeight : layer.height}
        draggable={layer.positionMode === "부분"}
        onDragEnd={(e) => {
          if (layer.positionMode === "부분") {
            onDragEnd(layer.id, e.target.x(), e.target.y());
          }
        }}
        onClick={() => onSelect(layer.id)}
        onContextMenu={(e) => {
          e.evt.preventDefault();
          onSelect(layer.id, { x: e.evt.clientX, y: e.evt.clientY }, true);
        }}
      />

      {/* 윤곽선 */}
      {layer.positionMode === "부분" && (
        <Rect
          x={layer.x}
          y={layer.y}
          width={layer.width}
          height={layer.height}
          stroke={outline.stroke}
          opacity={outline.opacity}
          dash={[4, 4]}
          listening={false}
        />
      )}
    </>
  );
}
