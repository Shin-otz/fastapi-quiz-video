// 📂 src/components/LayerList.js
import React, { useState } from "react";

export default function LayerList({ layers, selectedId, setSelectedId, setLayers }) {
  const [dragIndex, setDragIndex] = useState(null);

  const handleDragStart = (index) => {
    setDragIndex(index);
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    if (dragIndex === null || dragIndex === index) return;
    const updated = [...layers];
    const [removed] = updated.splice(dragIndex, 1);
    updated.splice(index, 0, removed);
    setDragIndex(index);
    setLayers(updated);
  };

  return (
    <div style={{ marginBottom: 15 }}>
      <h3>📄 레이어 순서</h3>
      <p style={{ fontSize: 12, color: "#666", marginTop: 0 }}>
        (마우스로 드래그하여 순서 변경)
      </p>
      {layers.map((layer, index) => (
        <div
          key={layer.id}
          draggable
          onDragStart={() => handleDragStart(index)}
          onDragOver={(e) => handleDragOver(e, index)}
          onClick={() => setSelectedId(layer.id)}
          style={{
            padding: "6px 8px",
            marginBottom: 4,
            background: layer.id === selectedId ? "#007bff" : "#f0f0f0",
            color: layer.id === selectedId ? "#fff" : "#000",
            borderRadius: 4,
            cursor: "grab",
            fontSize: 14,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            userSelect: "none"
          }}
        >
          <span>
            {layer.name}{" "}
            <span style={{ fontSize: 12, opacity: 0.7 }}>
              ({layer.type === "text" ? "텍스트" : "이미지"})
            </span>
          </span>
          {layer.id === selectedId && <span>✔</span>}
        </div>
      ))}
    </div>
  );
}
