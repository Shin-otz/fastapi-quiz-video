// 📂 src/components/Toolbar.js
import React from "react";

export default function Toolbar({ onAddText, onAddImage, onAddAudio, onAddCountdown }) {
  return (
    <div
      style={{
        width: 200,
        borderRight: "1px solid #ccc",
        padding: 10,
        boxSizing: "border-box",
        overflowY: "auto"
      }}
    >
      <h3>🎨 도구</h3>
      <button
        onClick={onAddText}
        style={{ width: "100%", marginBottom: 8, padding: "8px", fontSize: "14px", cursor: "pointer" }}
      >
        ➕ 텍스트 레이어
      </button>
      <button
        onClick={onAddImage}
        style={{ width: "100%", marginBottom: 8, padding: "8px", fontSize: "14px", cursor: "pointer" }}
      >
        🖼️ 이미지 레이어
      </button>
      <button
        onClick={onAddAudio}
        style={{ width: "100%", marginBottom: 8, padding: "8px", fontSize: "14px", cursor: "pointer" }}
      >
        🎧 오디오 레이어
      </button>
      <button
        onClick={onAddCountdown}
        style={{ width: "100%", marginBottom: 8, padding: "8px", fontSize: "14px", cursor: "pointer" }}
      >
        ⏳ 카운트다운 레이어
      </button>
    </div>
  );
}
