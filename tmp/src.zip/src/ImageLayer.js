import React from "react";
import { Image as KonvaImage, Rect } from "react-konva";
import useImage from "use-image";

/**
 * 이미지 레이어 전용 컴포넌트
 * @param {object} props
 * layer: 레이어 데이터
 * canvasWidth, canvasHeight: 현재 캔버스 크기
 * outline: 윤곽선 정보
 * onSelect: 클릭 또는 우클릭 시 호출
 * onDragEnd: 드래그 이동 끝날 때 호출
 */
export default function ImageLayer({ layer, canvasWidth, canvasHeight, outline, onSelect, onDragEnd }) {
  // useImage 훅은 컴포넌트 최상단에서만 사용 가능
  const [image] = useImage(layer.imgUrl, "anonymous");
  const isFull = layer.positionMode === "전체";

  return (
    <>
      <KonvaImage
        image={image}
        x={isFull ? 0 : layer.x}
        y={isFull ? 0 : layer.y}
        width={isFull ? canvasWidth : layer.width}
        height={isFull ? canvasHeight : layer.height}
        draggable={layer.positionMode === "부분"}
        onDragEnd={(e) => {
          if (layer.positionMode === "부분") onDragEnd(layer.id, e.target.x(), e.target.y());
        }}
        onClick={() => onSelect(layer.id)}
        onContextMenu={(e) => {
          e.evt.preventDefault();
          onSelect(layer.id, { x: e.evt.clientX, y: e.evt.clientY }, true);
        }}
      />
      {layer.positionMode === "부분" && (
        <Rect
          x={layer.x}
          y={layer.y}
          width={layer.width}
          height={layer.height}
          stroke={outline.stroke}
          opacity={outline.opacity}
          dash={[4, 4]}
          listening={false}
        />
      )}
    </>
  );
}
