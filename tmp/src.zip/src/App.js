// 📂 src/App.js (수정된 전체 코드)
// ✅ 기존 코드의 흐름과 기능은 모두 유지하면서 Canvas 정렬 기능을 추가했습니다.
// ✅ 주석은 최소화하고 원래 코드의 길이를 최대한 보존했습니다.

import React, { useState } from "react";
import { Stage, Layer, Rect, Text } from "react-konva";
import Toolbar from "./components/Toolbar";
import LayerOrderPanel from "./components/LayerOrderPanel";
import Timeline from "./components/Timeline";
import LayerProperties from "./components/LayerProperties";
import ImageLayer from "./components/ImageLayer";

export default function App() {
  const [layers, setLayers] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [currentTime, setCurrentTime] = useState(0);

  const resolutions = {
    "16:9": { width: 1920, height: 1080 },
    "1280x720": { width: 1280, height: 720 },
    "4:3": { width: 1024, height: 768 },
    "1:1": { width: 1080, height: 1080 },
    "9:16": { width: 1080, height: 1920 },
  };

  const [canvasRatio, setCanvasRatio] = useState("1280x720");
  const [displayScale, setDisplayScale] = useState(1);
  const realRes = resolutions[canvasRatio];
  const canvasWidth = realRes.width * displayScale;
  const canvasHeight = realRes.height * displayScale;

  const defaultDuration = 3;
  const sideWidth = 260;
  const topHeight = 110;
  const bottomHeight = 150;

  const recalculateLayerTimings = (srcLayers = layers) => {
    const newLayers = srcLayers.map(l => ({ ...l }));
    let timeCursor = 0;
    newLayers.forEach(layer => {
      if ((layer.type === "text" || layer.type === "countdown") && layer.timeMode === "부분") {
        const start = timeCursor + (layer.gapBefore || 0);
        let duration = layer.duration || defaultDuration;
        if (layer.type === "text" && layer.mp3Url && layer.mp3Url.trim() !== "") {
          duration = (layer.mp3PreGap || 0) + (layer.duration || defaultDuration) + (layer.mp3PostGap || 0);
        }
        layer.startTime = start;
        layer.endTime = start + duration;
        timeCursor = layer.endTime + (layer.gapAfter || 0);
      }
    });
    const totalDuration = timeCursor;
    newLayers.forEach(layer => {
      if (layer.timeMode === "전체" && (layer.type === "text" || layer.type === "countdown")) {
        layer.startTime = 0;
        layer.endTime = totalDuration;
      }
    });
    newLayers.forEach(layer => {
      if (layer.type === "audio") {
        if (layer.linkMode === "relative") {
          const base = newLayers.find(l => l.id === layer.linkedLayerId);
          if (base) {
            const anchor = layer.relativeAnchor === "end" ? base.endTime : base.startTime;
            layer.startTime = (anchor || 0) + (layer.offset || 0);
            layer.endTime = layer.startTime + (layer.duration || defaultDuration);
          }
        } else {
          layer.startTime = layer.gapBefore || 0;
          layer.endTime = layer.startTime + (layer.duration || defaultDuration);
        }
        if (layer.preGap) layer.startTime += layer.preGap;
        if (layer.postGap) layer.endTime += layer.postGap;
      }
    });
    newLayers.forEach(layer => {
      if (layer.type === "image" && layer.timeMode === "부분") {
        const startLayer = layer.linkedStartLayerId ? newLayers.find(l => l.id === layer.linkedStartLayerId) : null;
        const endLayer = layer.linkedEndLayerId ? newLayers.find(l => l.id === layer.linkedEndLayerId) : null;
        if (startLayer && endLayer) {
          layer.startTime = startLayer.startTime;
          const startIndex = newLayers.findIndex(l => l.id === startLayer.id);
          const endIndex = newLayers.findIndex(l => l.id === endLayer.id);
          let totalDuration = 0;
          if (startIndex !== -1 && endIndex !== -1 && endIndex >= startIndex) {
            const betweenLayers = newLayers.slice(startIndex, endIndex + 1);
            betweenLayers.forEach(l => {
              if ((l.type === "text" || l.type === "countdown") && l.timeMode === "부분") {
                totalDuration += (l.endTime - l.startTime);
              }
            });
          }
          layer.duration = totalDuration;
          layer.endTime = layer.startTime + layer.duration;
        } else {
          if (startLayer) layer.startTime = startLayer.startTime;
          if (endLayer) {
            layer.endTime = endLayer.endTime;
            layer.duration = layer.endTime - layer.startTime;
          }
        }
        if (layer.preGap) layer.startTime += layer.preGap;
        if (layer.postGap) layer.endTime += layer.postGap;
        layer.duration = layer.endTime - layer.startTime;
      }
    });
    setLayers(newLayers);
  };

  const addLayer = (type) => {
    const base = {
      id: Date.now(),
      name: `${type}${layers.length + 1}`,
      timeMode: "부분",
      positionMode: "부분",
      startTime: 0,
      endTime: 0,
      duration: defaultDuration,
      gapBefore: 0,
      gapAfter: 0,
      x: 50,
      y: 50,
      width: 200,
      height: 50,
      backgroundColor: "#ffffff",
      backgroundOpacity: 1,
      outlineMode: "normal",
      offsetPre: 0,
      offsetPost: 0,
      preGap: 0,
      postGap: 0,
      canvasAlign: "custom",
    };
    let newLayer = { ...base, type };
    if (type === "text") {
      newLayer.text = `텍스트${layers.length + 1}`;
      newLayer.mp3Key = `${newLayer.name}_mp3`;
      newLayer.mp3Url = "";
      newLayer.mp3PreGap = 0;
      newLayer.mp3PostGap = 0;
      newLayer.fontSize = 30;
      newLayer.color = "#000000";
      newLayer.textAlign = "left";
    }
    if (type === "image") {
      const firstPartial = layers.find(l => l.timeMode === "부분");
      const endTime = firstPartial ? firstPartial.endTime : defaultDuration;
      newLayer.imgUrl = "";
      newLayer.width = 300;
      newLayer.height = 200;
      newLayer.x = 100;
      newLayer.y = 100;
      newLayer.linkedStartLayerId = null;
      newLayer.linkedEndLayerId = null;
      newLayer.startTime = 0;
      newLayer.endTime = endTime;
      newLayer.duration = endTime;
    }
    if (type === "audio") {
      newLayer.audioUrl = "";
      newLayer.linkMode = "absolute";
      newLayer.linkedLayerId = null;
      newLayer.relativeAnchor = "start";
      newLayer.offset = 0;
    }
    if (type === "countdown") {
      newLayer.countdownStart = defaultDuration;
      newLayer.fontSize = 50;
      newLayer.color = "#ff0000";
    }
    const updated = [...layers, newLayer];
    recalculateLayerTimings(updated);
  };

  const updateLayer = (id, key, value) => {
    let updated = layers.map(l => {
      if (l.id !== id) return l;
      if (key === "name" && l.type === "text") {
        return { ...l, name: value, mp3Key: `${value}_mp3` };
      }
      return { ...l, [key]: value };
    });
    recalculateLayerTimings(updated);
  };

  const deleteLayer = (id) => {
    const updated = layers.filter(l => l.id !== id);
    setSelectedId(null);
    recalculateLayerTimings(updated);
  };

  const handleDragEnd = (id, x, y) => {
    setLayers(prev => prev.map(l => (l.id === id ? { ...l, x, y, canvasAlign: "custom" } : l)));
  };

  const isLayerVisible = (layer) => {
    if (layer.timeMode === "전체") return true;
    const start = (layer.startTime || 0) - (layer.offsetPre || 0);
    const end = (layer.endTime || 0) + (layer.offsetPost || 0);
    return currentTime >= start && currentTime <= end;
  };

  const getOutlineProps = (layer) => {
    let strokeColor = layer.id === selectedId ? "red" : "gray";
    let opacity = 1;
    if (layer.outlineMode === "transparent") opacity = 0;
    else if (layer.outlineMode === "semi") opacity = 0.3;
    return { stroke: strokeColor, opacity };
  };

  const selectedLayer = layers.find(l => l.id === selectedId);
  const maxTime = Math.max(...layers.map(l => l.endTime || 0), 0);
  const timelineWidth = canvasWidth * 0.8;

  return (
    <div style={{ display: "flex", height: "100vh" }}>
      <Toolbar
        onAddText={() => addLayer("text")}
        onAddImage={() => addLayer("image")}
        onAddAudio={() => addLayer("audio")}
        onAddCountdown={() => addLayer("countdown")}
      />
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <div style={{ height: topHeight, borderBottom: "1px solid #ccc", background: "#f5f5f5", padding: "0 10px", display: "flex", alignItems: "center", gap: 15 }}>
          <h4>🖥️ 해상도</h4>
          <select value={canvasRatio} onChange={(e) => setCanvasRatio(e.target.value)}>
            {Object.keys(resolutions).map(key => (
              <option key={key} value={key}>{key}</option>
            ))}
          </select>
          <label>Scale %</label>
          <input
            type="number"
            value={displayScale * 100}
            onChange={(e) => setDisplayScale(Math.max(0.1, Math.min(2, Number(e.target.value) / 100)))}
            style={{ width: 80 }}
          />
          <span>%</span>
          <button onClick={() => recalculateLayerTimings()} style={{ marginLeft: 20 }}>⏱️ 시간 재정렬</button>
          <div style={{ marginLeft: "auto" }}>전체시간: {maxTime.toFixed(1)}초</div>
        </div>
        <div style={{ flex: 1, background: "#eee", display: "flex", justifyContent: "center", alignItems: "center" }}>
          <Stage width={canvasWidth} height={canvasHeight} style={{ background: "#fff", boxShadow: "0 0 10px rgba(0,0,0,0.3)" }}>
            <Layer>
              <Rect x={0} y={0} width={canvasWidth} height={canvasHeight} stroke="red" strokeWidth={4} dash={[10, 5]} listening={false} />
              {layers.map(layer => {
                if (!isLayerVisible(layer)) return null;
                const outline = getOutlineProps(layer);
                if (layer.type === "text") {
                  let x = layer.x;
                  if (layer.canvasAlign === "left") x = 0;
                  else if (layer.canvasAlign === "center") x = (canvasWidth - layer.width) / 2;
                  else if (layer.canvasAlign === "right") x = canvasWidth - layer.width;
                  let y = layer.y;
                  return (
                    <React.Fragment key={layer.id}>
                      <Rect x={x} y={y} width={layer.width} height={layer.height} fill={layer.backgroundColor} opacity={layer.backgroundOpacity} />
                      <Rect x={x} y={y} width={layer.width} height={layer.height} stroke={outline.stroke} opacity={outline.opacity} dash={[4, 4]} />
                      <Text
                        text={layer.text}
                        x={x}
                        y={y}
                        width={layer.width}
                        height={layer.height}
                        fontSize={layer.fontSize}
                        fontFamily="Arial"
                        fill={layer.color}
                        align={layer.textAlign || "left"}
                        verticalAlign="middle"
                        draggable
                        onDragEnd={(e) => handleDragEnd(layer.id, e.target.x(), e.target.y())}
                        onClick={() => setSelectedId(layer.id)}
                      />
                    </React.Fragment>
                  );
                }
                if (layer.type === "image") {
                  return (
                    <ImageLayer
                      key={layer.id}
                      layer={layer}
                      canvasWidth={canvasWidth}
                      canvasHeight={canvasHeight}
                      isSelected={layer.id === selectedId}
                      onSelect={() => setSelectedId(layer.id)}
                      onDragEnd={handleDragEnd}
                    />
                  );
                }
                if (layer.type === "countdown") {
                  const elapsed = currentTime - layer.startTime;
                  let remaining = Math.max(layer.countdownStart - elapsed, 0);
                  remaining = Math.floor(remaining);
                  return (
                    <Text
                      key={layer.id}
                      text={String(remaining)}
                      x={layer.x}
                      y={layer.y}
                      fontSize={layer.fontSize}
                      fontFamily="Arial"
                      fill={layer.color}
                      align="center"
                      draggable
                      onDragEnd={(e) => handleDragEnd(layer.id, e.target.x(), e.target.y())}
                      onClick={() => setSelectedId(layer.id)}
                    />
                  );
                }
                return null;
              })}
            </Layer>
          </Stage>
        </div>
        <div style={{ height: bottomHeight, borderTop: "1px solid #ccc", background: "#f5f5f5", padding: 10, overflowX: "auto" }}>
          <Timeline
            layers={layers}
            setLayers={setLayers}
            currentTime={currentTime}
            setCurrentTime={setCurrentTime}
            selectedId={selectedId}
            setSelectedId={setSelectedId}
            maxTime={maxTime}
            timelineWidth={timelineWidth}
          />
        </div>
      </div>
      <div style={{ width: sideWidth, borderLeft: "1px solid #ccc", padding: 10, overflowY: "auto", display: "flex", flexDirection: "column", gap: 20 }}>
        <LayerOrderPanel
          layers={layers}
          selectedId={selectedId}
          setSelectedId={setSelectedId}
          moveLayer={(fromIndex, toIndex) => {
            setLayers(prev => {
              const newLayers = [...prev];
              const [moved] = newLayers.splice(fromIndex, 1);
              newLayers.splice(toIndex, 0, moved);
              setTimeout(() => recalculateLayerTimings(newLayers), 0);
              return newLayers;
            });
          }}
        />
        <LayerProperties
          selectedLayer={layers.find(l => l.id === selectedId)}
          updateLayer={updateLayer}
          deleteLayer={deleteLayer}
          layers={layers}
        />
      </div>
    </div>
  );
}
