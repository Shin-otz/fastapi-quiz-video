import express from 'express';
import fetch from 'node-fetch';
import cors from 'cors';

const app = express();
app.use(cors());

// 🔧 프록시 엔드포인트
app.get('/proxy-image', async (req, res) => {
  const imageUrl = req.query.url;
  if (!imageUrl) {
    return res.status(400).send('Missing url query parameter');
  }

  try {
    const response = await fetch(imageUrl);
    if (!response.ok) {
      return res.status(500).send('Failed to fetch image');
    }
    const buffer = await response.buffer();

    // 브라우저에서 Canvas로 그릴 수 있도록 CORS 허용
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Content-Type', 'image/jpeg');
    res.send(buffer);
  } catch (err) {
    console.error('❌ Error fetching image:', err);
    res.status(500).send('Error fetching image');
  }
});

// 서버 포트
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Proxy server running on http://localhost:${PORT}`);
});
